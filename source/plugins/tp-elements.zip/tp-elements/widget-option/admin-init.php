<?php

class TP_Elements_Addon_Control {

    private $tpelements_options;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'tpelements_add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'tpelements_page_init' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'tpelements_admin_scripts' ) );
        register_activation_hook( TPELEMENTS_FILE, [$this,'tpelements_plugin_activate'] );      
        
    }

    public function tpelements_admin_scripts(){
        wp_register_style('tpelements-admin-styles', TPELEMENTS_DIR_URL_PRO . 'widget-option/assets/css/tpelements-admin.css', array(), null );
        wp_enqueue_style('tpelements-admin-styles');
    }


    public function tpelements_add_plugin_page() {
        add_menu_page(
            'TP Elements Setting',
            'TP Elements',
            'manage_options',
            'tpelements-addon-settings',
            array( $this, 'tpelements_create_admin_page' ),
            'dashicons-superhero',
            6
        );
    }

    /**
     *
     */
    public function tpelements_create_admin_page() {
        $this->tpelements_options = get_option( 'tpelements_addon_option' );
        ?>
        <div class="wrap">
            <form class="tpelements-form" method="post" action="options.php">
                <?php
                settings_fields( 'tpelements_addon_group' );
                do_settings_sections( 'tpelements-addon-field' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }


    public function tpelements_page_init(){

        /**
         * Sanitize callback
         */
        register_setting(
            'tpelements_addon_group',
            'tpelements_addon_option',
            array( $this, 'tpelements_sanitize' )
        );

        

        add_settings_section(
            'tpelements_section_field_id',
            esc_html__( 'Disable Elements for better performance', 'tp-elements' ),
            array( $this, 'tpelements_section_info' ),
            'tpelements-addon-field'
        );

        /**
         * Image Showcase
         */
        add_settings_field(
            'tp_image_showcase',
            esc_html__( 'TP Image Showcase', 'tp-elements' ),
            array( $this, 'tpelements_image_showcase_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );


        /**
         * Full Width Slider ( Masum did not find )
         */
        add_settings_field(
            'tp_full_width_slider',
            esc_html__( 'TP Full Width Slider Masum', 'tp-elements' ),
            array( $this, 'tpelements_full_width_slider_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );
       
        /**
         * Button
         */
        add_settings_field(
            'tp_button',
            esc_html__( 'TP Button', 'tp-elements' ),
            array( $this, 'tpelements_button_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );
        /**
         * Logo Showcase
         */
        add_settings_field(
            'tp_logo_showcase',
            esc_html__( 'TP Logo Showcase', 'tp-elements' ),
            array( $this, 'tpelements_logo_showcase_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );

        /**
         * Blog Grid
         */
        add_settings_field(
            'tp_blog_grid',
            esc_html__( 'TP Blog Grid', 'tp-elements' ),
            array( $this, 'tpelements_blog_grid_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );

        /**
         * Countdown
         */
        add_settings_field(
            'tp_countdown_box',
            esc_html__( 'TP Countdown', 'tp-elements' ),
            array( $this, 'tpelements_countdown_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );

        /**
         * Marquee
         */
        add_settings_field(
            'tp_marquee',
            esc_html__( 'TP Marquee', 'tp-elements' ),
            array( $this, 'tpelements_marquee_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );
        /**
         * Line Draw
         */
        add_settings_field(
            'tp_linedraw',
            esc_html__( 'TP Line Draw', 'tp-elements' ),
            array( $this, 'tpelements_linedraw_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );

        /**
         * Portfolio Featurelist
         */
        add_settings_field(
            'tp_portfolio_featurelist',
            esc_html__( 'TP Portfolio Features', 'tp-elements' ),
            array( $this, 'tpelements_portfolio_featurelist_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );

        /**
         * Site Logo
         */
        add_settings_field(
            'tp_site_logo',
            esc_html__( 'TP Site Logo', 'tp-elements' ),
            array( $this, 'tpelements_site_logo_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );
        /**
         * Site Search
         */
        add_settings_field(
            'tp_site_search',
            esc_html__( 'TP Search', 'tp-elements' ),
            array( $this, 'tpelements_site_search_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );
        /**
         * Site Canvas
         */
        add_settings_field(
            'tp_site_canvas',
            esc_html__( 'OffCanvas Hamburger', 'tp-elements' ),
            array( $this, 'tpelements_site_canvas_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );
        /**
         * Site Navigation
         */
        add_settings_field(
            'tp_site_navigation',
            esc_html__( 'Navigation Menu', 'tp-elements' ),
            array( $this, 'tpelements_site_navigation_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );
        /**
         * Scroll To Top
         */
        add_settings_field(
            'tp_scroll_to_top',
            esc_html__( 'TP Scroll To Top', 'tp-elements' ),
            array( $this, 'tpelements_scroll_to_top_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );

        /**
         * Single Navigation
         */
        add_settings_field(
            'tp_single_navigation',
            esc_html__( 'Single Page Navigation', 'tp-elements' ),
            array( $this, 'tpelements_single_navigation_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );

        /**
         * Copyright
         */
        add_settings_field(
            'tp_copyright',
            esc_html__( 'TP Copyright', 'tp-elements' ),
            array( $this, 'tpelements_copyright_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );

        /**
         * Cart
         */
        add_settings_field(
            'tp_cart',
            esc_html__( 'TP Woo Cart', 'tp-elements' ),
            array( $this, 'tpelements_cart_setting' ),
            'tpelements-addon-field',
            'tpelements_section_field_id',
            array( 'class' => 'tpselements_addon_field' )
        );


    }

    /**
     * Sanitize all form
     */
    public function tpelements_sanitize( $input_addon ) {
        $rt_addon_arg = array();

        //Full Width Slider
        if( isset( $input_addon['tp_full_width_slider_setting'] ) ){
            $rt_addon_arg['tp_full_width_slider_setting'] = sanitize_text_field( $input_addon['tp_full_width_slider_setting'] );
        }

        //Button
        if( isset( $input_addon['tp_button_setting'] ) ){
            $rt_addon_arg['tp_button_setting'] = sanitize_text_field( $input_addon['tp_button_setting'] );
        }
        //Logo Showcase
        if( isset( $input_addon['tp_logo_showcase_setting'] ) ){
            $rt_addon_arg['tp_logo_showcase_setting'] = sanitize_text_field( $input_addon['tp_logo_showcase_setting'] );
        }
        //Blog Grid
        if( isset( $input_addon['tp_blog_grid_setting'] ) ){
            $rt_addon_arg['tp_blog_grid_setting'] = sanitize_text_field( $input_addon['tp_blog_grid_setting'] );
        }

        //Image Showcase
        if( isset( $input_addon['tp_image_showcase_setting'] ) ){
            $rt_addon_arg['tp_image_showcase_setting'] = sanitize_text_field( $input_addon['tp_image_showcase_setting'] );
        }

        //Marquee
        if( isset( $input_addon['tp_marquee_setting'] ) ){
            $rt_addon_arg['tp_marquee_setting'] = sanitize_text_field( $input_addon['tp_marquee_setting'] );
        }
        //Line Draw
        if( isset( $input_addon['tp_linedraw_setting'] ) ){
            $rt_addon_arg['tp_linedraw_setting'] = sanitize_text_field( $input_addon['tp_linedraw_setting'] );
        }

        //Site Logo
        if( isset( $input_addon['tp_site_logo_setting'] ) ){
            $rt_addon_arg['tp_site_logo_setting'] = sanitize_text_field( $input_addon['tp_site_logo_setting'] );
        }

        //Site Search
        if( isset( $input_addon['tp_site_search_setting'] ) ){
            $rt_addon_arg['tp_site_search_setting'] = sanitize_text_field( $input_addon['tp_site_search_setting'] );
        }

        //Site Canvas
        if( isset( $input_addon['tp_site_canvas_setting'] ) ){
            $rt_addon_arg['tp_site_canvas_setting'] = sanitize_text_field( $input_addon['tp_site_canvas_setting'] );
        }

        //Site Navigation
        if( isset( $input_addon['tp_site_navigation_setting'] ) ){
            $rt_addon_arg['tp_site_navigation_setting'] = sanitize_text_field( $input_addon['tp_site_navigation_setting'] );
        }

        //Sroll To Top
        if( isset( $input_addon['tp_scroll_to_top_setting'] ) ){
            $rt_addon_arg['tp_scroll_to_top_setting'] = sanitize_text_field( $input_addon['tp_scroll_to_top_setting'] );
        }

        //Single Navigation
        if( isset( $input_addon['tp_single_navigation_setting'] ) ){
            $rt_addon_arg['tp_single_navigation_setting'] = sanitize_text_field( $input_addon['tp_single_navigation_setting'] );
        }

        //Copyright
        if( isset( $input_addon['tp_copyright_setting'] ) ){
            $rt_addon_arg['tp_copyright_setting'] = sanitize_text_field( $input_addon['tp_copyright_setting'] );
        }

        //Cart
        if( isset( $input_addon['tp_cart_setting'] ) ){
            $rt_addon_arg['tp_cart_setting'] = sanitize_text_field( $input_addon['tp_cart_setting'] );
        }


        return $rt_addon_arg;
    }

    /**
     * Print the Section text
     */
    public function tpelements_section_info() {
        //print 'Enter your settings below:';
    }

    /**
     * Full Width Slider
     */
    public function tpelements_full_width_slider_setting() {
        ?>
        <div class="checkbox">
            <?php
            printf('<input type="checkbox" name="tpelements_addon_option[tp_full_width_slider_setting]" id="tp_full_width_slider_setting" value="tpelement_full_width_slider" %s/>',
                (isset( $this->tpelements_options['tp_full_width_slider_setting']) && $this->tpelements_options['tp_full_width_slider_setting'] ) == 'tpelement_full_width_slider' ? 'checked' : ''
            );
            ?>
            <label for="tp_full_width_slider_setting"></label>
        </div>
        <?php
    }

    /**
     * Button
     */
    public function tpelements_button_setting() {
        ?>
        <div class="checkbox">
            <?php
            printf('<input type="checkbox" name="tpelements_addon_option[tp_button_setting]" id="tp_button_setting" value="tpelement_button" %s/>',
                (isset( $this->tpelements_options['tp_button_setting']) && $this->tpelements_options['tp_button_setting'] ) == 'tpelement_button' ? 'checked' : ''
            );
            ?>
            <label for="tp_button_setting"></label>
        </div>
        <?php
    }
    
    /**
     * Logo Showcase
     */
    public function tpelements_logo_showcase_setting() {
        ?>
        <div class="checkbox">
            <?php
            printf('<input type="checkbox" name="tpelements_addon_option[tp_logo_showcase_setting]" id="tp_logo_showcase_setting" value="tpelement_logo_showcase" %s/>',
                (isset( $this->tpelements_options['tp_logo_showcase_setting']) && $this->tpelements_options['tp_logo_showcase_setting'] ) == 'tpelement_logo_showcase' ? 'checked' : ''
            );
            ?>
            <label for="tp_logo_showcase_setting"></label>
        </div>
        <?php
    }

    /**
     * Blog Grid
     */
    public function tpelements_blog_grid_setting() {
        ?>
        <div class="checkbox">
            <?php
            printf('<input type="checkbox" name="tpelements_addon_option[tp_blog_grid_setting]" id="tp_blog_grid_setting" value="tpelement_blog_grid" %s/>',
                (isset( $this->tpelements_options['tp_blog_grid_setting']) && $this->tpelements_options['tp_blog_grid_setting'] ) == 'tpelement_blog_grid' ? 'checked' : ''
            );
            ?>
            <label for="tp_blog_grid_setting"></label>
        </div>
        <?php
    }

    /**
     * Image Showcase
     */
    public function tpelements_image_showcase_setting() {
        ?>
        <div class="checkbox">
            <?php
            printf('<input type="checkbox" name="tpelements_addon_option[tp_image_showcase_setting]" id="tp_image_showcase_setting" value="tpelement_image_showcase" %s/>',
                (isset( $this->tpelements_options['tp_image_showcase_setting']) && $this->tpelements_options['tp_image_showcase_setting'] ) == 'tpelement_image_showcase' ? 'checked' : ''
            );
            ?>
            <label for="tp_image_showcase_setting"></label>
        </div>
        <?php
    }

    /**
     * Marquee
     */
    public function tpelements_marquee_setting() {
        ?>
        <div class="checkbox">
            <?php

            printf('<input type="checkbox" name="tpelements_addon_option[tp_marquee_setting]" id="tp_marquee_setting" value="tpelement_marquee" %s/>',
                (isset( $this->tpelements_options['tp_marquee_setting']) && $this->tpelements_options['tp_marquee_setting'] ) == 'tpelement_marquee' ? 'checked' : ''
            );
            ?>
            <label for="tp_marquee_setting"></label>
        </div>
        <?php
    }

    /**
     * Line Draw
     */
    public function tpelements_linedraw_setting() {
        ?>
        <div class="checkbox">
            <?php

            printf('<input type="checkbox" name="tpelements_addon_option[tp_linedraw_setting]" id="tp_linedraw_setting" value="tpelement_linedraw" %s/>',
                (isset( $this->tpelements_options['tp_linedraw_setting']) && $this->tpelements_options['tp_linedraw_setting'] ) == 'tpelement_linedraw' ? 'checked' : ''
            );
            ?>
            <label for="tp_linedraw_setting"></label>
        </div>
        <?php
    }

    /**
     * Site Logo
     */
    public function tpelements_site_logo_setting() {
        ?>
        <div class="checkbox">
            <?php

            printf('<input type="checkbox" name="tpelements_addon_option[tp_site_logo_setting]" id="tp_site_logo_setting" value="tpelement_site_logo" %s/>',
                (isset( $this->tpelements_options['tp_site_logo_setting']) && $this->tpelements_options['tp_site_logo_setting'] ) == 'tpelement_site_logo' ? 'checked' : ''
            );
            ?>
            <label for="tp_site_logo_setting"></label>
        </div>
        <?php
    }
    /**
     * Site Search
     */
    public function tpelements_site_search_setting() {
        ?>
        <div class="checkbox">
            <?php

            printf('<input type="checkbox" name="tpelements_addon_option[tp_site_search_setting]" id="tp_site_search_setting" value="tpelement_site_search" %s/>',
                (isset( $this->tpelements_options['tp_site_search_setting']) && $this->tpelements_options['tp_site_search_setting'] ) == 'tpelement_site_search' ? 'checked' : ''
            );
            ?>
            <label for="tp_site_search_setting"></label>
        </div>
        <?php
    }

    /**
     * Site Canvas
     */
    public function tpelements_site_canvas_setting() {
        ?>
        <div class="checkbox">
            <?php

            printf('<input type="checkbox" name="tpelements_addon_option[tp_site_canvas_setting]" id="tp_site_canvas_setting" value="tpelement_site_canvas" %s/>',
                (isset( $this->tpelements_options['tp_site_canvas_setting']) && $this->tpelements_options['tp_site_canvas_setting'] ) == 'tpelement_site_canvas' ? 'checked' : ''
            );
            ?>
            <label for="tp_site_canvas_setting"></label>
        </div>
        <?php
    }

    /**
     * Site Navigation
     */
    public function tpelements_site_navigation_setting() {
        ?>
        <div class="checkbox">
            <?php

            printf('<input type="checkbox" name="tpelements_addon_option[tp_site_navigation_setting]" id="tp_site_navigation_setting" value="tpelement_site_navigation" %s/>',
                (isset( $this->tpelements_options['tp_site_navigation_setting']) && $this->tpelements_options['tp_site_navigation_setting'] ) == 'tpelement_site_navigation' ? 'checked' : ''
            );
            ?>
            <label for="tp_site_navigation_setting"></label>
        </div>
        <?php
    }

    /**
     * Scroll To Top
     */
    public function tpelements_scroll_to_top_setting() {
        ?>
        <div class="checkbox">
            <?php

            printf('<input type="checkbox" name="tpelements_addon_option[tp_scroll_to_top_setting]" id="tp_scroll_to_top_setting" value="tpelement_scroll_to_top" %s/>',
                (isset( $this->tpelements_options['tp_scroll_to_top_setting']) && $this->tpelements_options['tp_scroll_to_top_setting'] ) == 'tpelement_scroll_to_top' ? 'checked' : ''
            );
            ?>
            <label for="tp_scroll_to_top_setting"></label>
        </div>
        <?php
    }


    /**
     * Single Navigation
     */
    public function tpelements_single_navigation_setting() {
        ?>
        <div class="checkbox">
            <?php

            printf('<input type="checkbox" name="tpelements_addon_option[tp_single_navigation_setting]" id="tp_single_navigation_setting" value="tpelement_single_navigation" %s/>',
                (isset( $this->tpelements_options['tp_single_navigation_setting']) && $this->tpelements_options['tp_single_navigation_setting'] ) == 'tpelement_single_navigation' ? 'checked' : ''
            );
            ?>
            <label for="tp_single_navigation_setting"></label>
        </div>
        <?php
    }

    /**
     * Copyright
     */
    public function tpelements_copyright_setting() {
        ?>
        <div class="checkbox">
            <?php

            printf('<input type="checkbox" name="tpelements_addon_option[tp_copyright_setting]" id="tp_copyright_setting" value="tpelement_copyright" %s/>',
                (isset( $this->tpelements_options['tp_copyright_setting']) && $this->tpelements_options['tp_copyright_setting'] ) == 'tpelement_copyright' ? 'checked' : ''
            );
            ?>
            <label for="tp_copyright_setting"></label>
        </div>
        <?php
    }

    /**
     * Cart
     */
    public function tpelements_cart_setting() {
        ?>
        <div class="checkbox">
            <?php

            printf('<input type="checkbox" name="tpelements_addon_option[tp_cart_setting]" id="tp_cart_setting" value="tpelement_cart" %s/>',
                (isset( $this->tpelements_options['tp_cart_setting']) && $this->tpelements_options['tp_cart_setting'] ) == 'tpelement_cart' ? 'checked' : ''
            );
            ?>
            <label for="tp_cart_setting"></label>
        </div>
        <?php
    }



    public function tpelements_plugin_activate() {
        $all_elements_list = $this->tpelements_widget_list();

        update_option('tpelements_addon_option',$all_elements_list);
    }

    public function tpelements_widget_list() {
        $tpall_elements = [
            'tp_cart_setting' => 'tpelement_cart',
            'tp_copyright_setting' => 'tpelement_copyright',
            'tp_single_navigation_setting' => 'tpelement_single_navigation',
            'tp_scroll_to_top_setting' => 'tpelement_scroll_to_top',
            'tp_site_navigation_setting' => 'tpelement_site_navigation',
            'tp_site_canvas_setting' => 'tpelement_site_canvas',
            'tp_site_search_setting' => 'tpelement_site_search',
            'tp_site_logo_setting' => 'tpelement_site_logo',
            'tp_linedraw_setting' => 'tpelement_linedraw',
            'tp_marquee_setting' => 'tpelement_marquee',
            'tp_full_width_slider_setting' => 'tpelement_full_width_slider',
            'tp_button_setting' => 'tpelement_button',
            'tp_logo_showcase_setting' => 'tpelement_logo_showcase',
            'tp_blog_grid_setting' => 'tpelement_blog_grid',
            'tp_image_showcase_setting' => 'tpelement_image_showcase',   
           
        ];

        return $tpall_elements;
    }
    
}

if( is_admin() )
    new TP_Elements_Addon_Control();